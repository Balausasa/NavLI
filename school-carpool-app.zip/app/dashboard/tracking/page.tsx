"use client"

import { useState, useEffect } from "react"
import { Car, MapPin, Clock, Phone, CheckCircle2, Navigation, School, ArrowRight, Route, ShieldCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

type TrackingStatus = "waiting" | "pickup" | "en-route" | "arrived"
type UserMode = "driver" | "passenger"

const statusLabels: Record<TrackingStatus, string> = {
  waiting: "Ожидание",
  pickup: "Забираем детей",
  "en-route": "В пути к НИШ Актау",
  arrived: "Прибыл в НИШ Актау",
}

const statusColors: Record<TrackingStatus, string> = {
  waiting: "bg-warning text-warning-foreground",
  pickup: "bg-primary text-primary-foreground",
  "en-route": "bg-accent text-accent-foreground",
  arrived: "bg-success text-success-foreground",
}

const pickupTasks = [
  { name: "Иванов Петр", address: "14 мкр, д. 45", cls: "5А", picked: false },
  { name: "Серикова Мадина", address: "14 мкр, д. 32", cls: "4Б", picked: false },
  { name: "Ким Данияр", address: "14 мкр, д. 21", cls: "4Б", picked: false },
]

const routeOptions = [
  { id: "optimal", label: "Оптимальный", time: "12 мин", desc: "Сбалансированный: быстро и безопасно", color: "border-primary bg-primary/5" },
  { id: "safe", label: "Безопасный", time: "15 мин", desc: "Минимум перекрестков, школьные зоны", color: "border-success bg-success/5" },
  { id: "notraffic", label: "Без пробок", time: "14 мин", desc: "Обход утренних заторов у школ", color: "border-accent bg-accent/5" },
]

export default function TrackingPage() {
  const [status, setStatus] = useState<TrackingStatus>("waiting")
  const [eta, setEta] = useState(12)
  const [mode, setMode] = useState<UserMode>("driver")
  const [tasks, setTasks] = useState(pickupTasks)
  const [selectedRoute, setSelectedRoute] = useState("optimal")

  // Check role from localStorage
  useEffect(() => {
    if (typeof window !== "undefined") {
      const hasTransport = localStorage.getItem("navli_hasTransport")
      if (hasTransport === "false") setMode("passenger")
    }
  }, [])

  useEffect(() => {
    const interval = setInterval(() => setEta((prev) => (prev <= 0 ? 0 : prev - 1)), 1000)
    return () => clearInterval(interval)
  }, [])

  const markPicked = (index: number) => {
    setTasks((prev) => prev.map((t, i) => i === index ? { ...t, picked: true } : t))
  }

  // === DRIVER VIEW ===
  if (mode === "driver") {
    return (
      <div className="flex h-full flex-col">
        <div className="border-b border-border bg-card px-4 py-4 lg:px-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "var(--font-heading)" }}>Режим водителя</h1>
              <p className="text-sm text-muted-foreground">Сегодня ваше дежурство | 14 мкр - НИШ Актау</p>
            </div>
            <div className={cn("rounded-full px-3 py-1 text-xs font-semibold", statusColors[status])}>{statusLabels[status]}</div>
          </div>
        </div>

        <div className="flex flex-1 flex-col lg:flex-row">
          {/* Map */}
          <div className="relative flex-1">
            <iframe
              title="Карта маршрута Актау"
              src="https://www.openstreetmap.org/export/embed.html?bbox=51.11%2C43.64%2C51.17%2C43.67&layer=mapnik&marker=43.6535%2C51.1575"
              className="h-full w-full min-h-[400px] border-0"
              allowFullScreen
            />
            {status !== "arrived" && (
              <div className="absolute bottom-4 left-1/2 z-10 -translate-x-1/2">
                <div className="flex items-center gap-3 rounded-full border border-border bg-card px-5 py-2.5 shadow-lg">
                  <Navigation className="h-4 w-4 text-primary" />
                  <span className="text-lg font-bold text-foreground" style={{ fontFamily: "var(--font-heading)" }}>{eta} мин</span>
                  <span className="text-xs text-muted-foreground">до НИШ</span>
                </div>
              </div>
            )}
          </div>

          {/* Driver control panel */}
          <div className="w-full overflow-auto border-t border-border bg-card lg:w-96 lg:border-l lg:border-t-0">
            {/* Status buttons */}
            <div className="border-b border-border p-4">
              <h2 className="mb-3 text-sm font-semibold text-foreground">Управление поездкой</h2>
              <div className="grid grid-cols-2 gap-2">
                <Button size="sm" variant={status === "waiting" ? "default" : "outline"} onClick={() => { setStatus("waiting"); setEta(12) }} className="text-xs">Ожидаю ребенка</Button>
                <Button size="sm" variant={status === "pickup" ? "default" : "outline"} onClick={() => { setStatus("pickup"); setEta(10) }} className="text-xs">Забрал ребенка</Button>
                <Button size="sm" variant={status === "en-route" ? "default" : "outline"} onClick={() => { setStatus("en-route"); setEta(6) }} className="text-xs">В пути</Button>
                <Button size="sm" variant={status === "arrived" ? "default" : "outline"} onClick={() => { setStatus("arrived"); setEta(0) }} className="text-xs">Поездка завершена</Button>
              </div>
            </div>

            {/* Pickup tasks */}
            <div className="border-b border-border p-4">
              <h2 className="mb-3 text-sm font-semibold text-foreground">Задания на сбор</h2>
              <div className="space-y-2">
                {tasks.map((task, i) => (
                  <div key={task.name} className={cn("flex items-center gap-3 rounded-xl border p-3 transition-all", task.picked ? "border-success/30 bg-success/5" : "border-border")}>
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent/10 text-xs font-bold text-accent">{i + 1}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{task.name}</p>
                      <p className="truncate text-xs text-muted-foreground">{task.address} | {task.cls}</p>
                    </div>
                    {task.picked ? (
                      <CheckCircle2 className="h-5 w-5 shrink-0 text-success" />
                    ) : (
                      <Button size="sm" variant="outline" onClick={() => markPicked(i)} className="shrink-0 text-xs gap-1">
                        <ArrowRight className="h-3 w-3" /> Забрал
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Route recommendations */}
            <div className="p-4">
              <h2 className="mb-1 text-sm font-semibold text-foreground">ИИ рекомендация маршрута</h2>
              <p className="mb-3 text-xs text-muted-foreground">ИИ проанализировал пробки и выбрал лучший вариант</p>
              <div className="space-y-2">
                {routeOptions.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => setSelectedRoute(r.id)}
                    className={cn("flex w-full items-center gap-3 rounded-xl border-2 p-3 text-left transition-all", selectedRoute === r.id ? r.color : "border-border bg-card hover:border-border")}
                  >
                    <Route className={cn("h-5 w-5 shrink-0", selectedRoute === r.id ? "text-primary" : "text-muted-foreground")} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-foreground">{r.label}</span>
                        <span className="text-xs font-bold text-primary">{r.time}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">{r.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Demo toggle */}
            <div className="border-t border-border p-4">
              <p className="mb-2 text-xs text-muted-foreground">Демо: переключить режим</p>
              <Button variant="outline" size="sm" className="w-full text-xs" onClick={() => setMode("passenger")}>
                Переключить на режим родителя без авто
              </Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // === PASSENGER (non-driver parent) VIEW ===
  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-border bg-card px-4 py-4 lg:px-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "var(--font-heading)" }}>Отслеживание ребенка</h1>
            <p className="text-sm text-muted-foreground">Пассивное отслеживание | 14 мкр - НИШ Актау</p>
          </div>
          <div className={cn("rounded-full px-3 py-1 text-xs font-semibold", statusColors[status])}>{statusLabels[status]}</div>
        </div>
      </div>

      <div className="flex flex-1 flex-col lg:flex-row">
        <div className="relative flex-1">
          <iframe
            title="Карта маршрута Актау"
            src="https://www.openstreetmap.org/export/embed.html?bbox=51.11%2C43.64%2C51.17%2C43.67&layer=mapnik&marker=43.6535%2C51.1575"
            className="h-full w-full min-h-[400px] border-0"
            allowFullScreen
          />
          <div className="absolute left-4 right-4 top-4 z-10 sm:left-4 sm:right-auto sm:w-80">
            <div className="rounded-2xl border border-border bg-card p-4 shadow-lg">
              {status === "waiting" && (
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5 text-warning" />
                  <div>
                    <p className="text-sm font-semibold text-foreground">Водитель выезжает через {eta} мин</p>
                    <p className="text-xs text-muted-foreground">Петров Кайрат заберет вашего ребенка</p>
                  </div>
                </div>
              )}
              {status === "pickup" && (
                <div className="flex items-center gap-3">
                  <Car className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm font-semibold text-foreground">Водитель забирает вашего ребенка</p>
                    <p className="text-xs text-muted-foreground">Иванов Петр садится в машину</p>
                  </div>
                </div>
              )}
              {status === "en-route" && (
                <div className="flex items-center gap-3">
                  <Navigation className="h-5 w-5 text-accent" />
                  <div>
                    <p className="text-sm font-semibold text-foreground">Ваш ребенок в машине</p>
                    <p className="text-xs text-muted-foreground">Прибытие в НИШ Актау через {eta} мин</p>
                  </div>
                </div>
              )}
              {status === "arrived" && (
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="h-5 w-5 text-success" />
                  <div>
                    <p className="text-sm font-semibold text-success">Ребенок доставлен в НИШ Актау</p>
                    <p className="text-xs text-muted-foreground">Прибыл в 07:50, все в порядке</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Passive info panel */}
        <div className="w-full overflow-auto border-t border-border bg-card lg:w-80 lg:border-l lg:border-t-0">
          <div className="border-b border-border p-4">
            <h2 className="mb-3 text-sm font-semibold text-foreground">Водитель сегодня</h2>
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-lg font-bold text-primary-foreground">ПК</div>
              <div className="flex-1">
                <p className="font-medium text-foreground">Петров Кайрат</p>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <ShieldCheck className="h-3 w-3 text-success" />
                  Face ID подтвержден
                </div>
              </div>
            </div>
            <Button variant="outline" size="sm" className="mt-3 w-full gap-2"><Phone className="h-3 w-3" /> Позвонить водителю</Button>
          </div>

          <div className="border-b border-border p-4">
            <h2 className="mb-3 text-sm font-semibold text-foreground">Автомобиль</h2>
            <div className="space-y-2">
              <InfoRow label="Марка" value="Kia Sportage" />
              <InfoRow label="Цвет" value="Серый" />
              <InfoRow label="Госномер" value="789 GHI 15" />
            </div>
          </div>

          <div className="border-b border-border p-4">
            <h2 className="mb-3 text-sm font-semibold text-foreground">Статус ребенка</h2>
            <div className="space-y-3">
              <StatusStep icon={<Clock className="h-4 w-4" />} label="Водитель выехал" time="07:25" active />
              <StatusStep icon={<MapPin className="h-4 w-4" />} label="Забрал вашего ребенка" time={status !== "waiting" ? "07:30" : "~07:30"} active={status !== "waiting"} />
              <StatusStep icon={<Car className="h-4 w-4" />} label="Ребенок в машине, в пути" time={["en-route","arrived"].includes(status) ? "07:35" : "~07:35"} active={["en-route","arrived"].includes(status)} />
              <StatusStep icon={<School className="h-4 w-4" />} label="Прибыл в НИШ Актау" time={status === "arrived" ? "07:50" : "~07:50"} active={status === "arrived"} />
            </div>
          </div>

          {/* Demo controls */}
          <div className="p-4">
            <p className="mb-2 text-xs text-muted-foreground">Демо: изменить статус</p>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" size="sm" onClick={() => { setStatus("waiting"); setEta(12) }} className="text-xs">Ожидание</Button>
              <Button variant="outline" size="sm" onClick={() => { setStatus("pickup"); setEta(8) }} className="text-xs">Забирает</Button>
              <Button variant="outline" size="sm" onClick={() => { setStatus("en-route"); setEta(5) }} className="text-xs">В пути</Button>
              <Button variant="outline" size="sm" onClick={() => { setStatus("arrived"); setEta(0) }} className="text-xs">Прибыл</Button>
            </div>
            <Button variant="outline" size="sm" className="mt-2 w-full text-xs" onClick={() => setMode("driver")}>
              Переключить на режим водителя
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-xl bg-secondary/50 px-3 py-2">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-sm font-medium text-foreground">{value}</span>
    </div>
  )
}

function StatusStep({ icon, label, time, active }: { icon: React.ReactNode; label: string; time: string; active: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-full", active ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground")}>{icon}</div>
      <div className="flex-1">
        <p className={cn("text-sm", active ? "font-medium text-foreground" : "text-muted-foreground")}>{label}</p>
        <p className="text-xs text-muted-foreground">{time}</p>
      </div>
      {active && <CheckCircle2 className="h-4 w-4 shrink-0 text-success" />}
    </div>
  )
}
